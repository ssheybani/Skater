"""Making LimeTabularExplainer Accessible"""
from lime.lime_tabular import LimeTabularExplainer
