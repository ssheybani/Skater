"""Making LimeImageExplainer Accessible"""
from lime.lime_image import LimeImageExplainer
